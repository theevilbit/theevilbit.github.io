//#include <ntddk.h>
#include <stdio.h>
#include <stdlib.h>
#include <ntstatus.h>
#include <ntstrsafe.h>
#include <Ntifs.h>

//#include "driver.h"

typedef char * string;

//Define IOCTL codes
#define IOCTL_DROP_FILE CTL_CODE(FILE_DEVICE_UNKNOWN, 0x800, METHOD_IN_DIRECT, FILE_READ_DATA | FILE_WRITE_DATA)

//This function will drop a file if the proper IOCTL code is called.
NTSTATUS drop_file()
{
	UNICODE_STRING     uniName;
	OBJECT_ATTRIBUTES  objAttr;

	RtlInitUnicodeString(&uniName, L"\\DosDevices\\C:\\WINDOWS\\example.txt");  // or L"\\SystemRoot\\example.txt"
	InitializeObjectAttributes(&objAttr, &uniName,
		OBJ_CASE_INSENSITIVE | OBJ_KERNEL_HANDLE,
		NULL, NULL);

	HANDLE   handle;
	NTSTATUS ntstatus;
	IO_STATUS_BLOCK    ioStatusBlock;

	// Do not try to perform any file operations at higher IRQL levels.
	// Instead, you may use a work item or a system worker thread to perform file operations.

	if (KeGetCurrentIrql() != PASSIVE_LEVEL)
		return STATUS_INVALID_DEVICE_STATE;

	ntstatus = ZwCreateFile(&handle,
		GENERIC_WRITE,
		&objAttr, &ioStatusBlock, NULL,
		FILE_ATTRIBUTE_NORMAL,
		0,
		FILE_OVERWRITE_IF,
		FILE_SYNCHRONOUS_IO_NONALERT,
		NULL, 0);
	CHAR     buffer[30];
	size_t  cb;

	if (NT_SUCCESS(ntstatus)) {
		ntstatus = RtlStringCbPrintfA(buffer, sizeof(buffer), "This is %d test\r\n", 0x0);
		if (NT_SUCCESS(ntstatus)) {
			ntstatus = RtlStringCbLengthA(buffer, sizeof(buffer), &cb);
			if (NT_SUCCESS(ntstatus)) {
				ntstatus = ZwWriteFile(handle, NULL, NULL, NULL, &ioStatusBlock, buffer, cb, NULL, NULL);
			}
		}
		ZwClose(handle);
	}
	return STATUS_SUCCESS;

}

NTSTATUS my_UnSupportedFunction(PDEVICE_OBJECT DeviceObject, PIRP Irp)
{
	//DbgPrint("my_UnSupportedFunction Called \r\n");
	return STATUS_NOT_SUPPORTED;
}

/*
IOCTL control function. IOCTL codes used to switch ON/OFF faking VMs
*/

NTSTATUS my_IOCTLControl(PDEVICE_OBJECT DeviceObject, PIRP Irp)
{
	NTSTATUS my_status = STATUS_NOT_SUPPORTED;
	PIO_STACK_LOCATION pIoStackIrp = NULL;
	ULONG dwDataWritten = 0;
	ULONG inBufferLength, outBufferLength, requestcode;

	// Recieve the IRP stack location from system
	pIoStackIrp = IoGetCurrentIrpStackLocation(Irp);

	PCHAR inBuf = (PCHAR)Irp->AssociatedIrp.SystemBuffer;
	PCHAR buffer = NULL;

	PCHAR data = "This String is from Device Driver !!!";
	size_t datalen = strlen(data) + 1;//Length of data including null
	if (pIoStackIrp) /* Should Never Be NULL! */
	{
		// Recieve the buffer lengths, and request code
		inBufferLength = pIoStackIrp->Parameters.DeviceIoControl.InputBufferLength;
		outBufferLength = pIoStackIrp->Parameters.DeviceIoControl.OutputBufferLength;
		requestcode = pIoStackIrp->Parameters.DeviceIoControl.IoControlCode;
		switch (requestcode)
		{
		case IOCTL_DROP_FILE:
			my_status = drop_file();
			break;
		default:
			my_status = STATUS_INVALID_DEVICE_REQUEST;
			break;

		}
	}

	Irp->IoStatus.Status = my_status;
	Irp->IoStatus.Information = dwDataWritten;
	IoCompleteRequest(Irp, IO_NO_INCREMENT);
	return my_status;
}

void my_Unload(PDRIVER_OBJECT pDriverObject)
{
	DbgPrint("Unload routine called.\n");

	UNICODE_STRING usDosDeviceName;
	RtlInitUnicodeString(&usDosDeviceName, L"\\DosDevices\\workshop");
	IoDeleteSymbolicLink(&usDosDeviceName);
	IoDeleteDevice(pDriverObject->DeviceObject);
}

NTSTATUS DriverEntry(PDRIVER_OBJECT pDriverObject, PUNICODE_STRING pRegistryPath)
{

	UNICODE_STRING usDriverName, usDosDeviceName;
	PDEVICE_OBJECT pDeviceObject = NULL;
	NTSTATUS my_status = STATUS_SUCCESS;
	unsigned int uiIndex = 0;

	DbgPrint("DriverEntry Called.\n");

	RtlInitUnicodeString(&usDriverName, L"\\Device\\workshop");
	RtlInitUnicodeString(&usDosDeviceName, L"\\DosDevices\\workshop");

	my_status = IoCreateDevice(pDriverObject, 0, &usDriverName, FILE_DEVICE_UNKNOWN, FILE_DEVICE_SECURE_OPEN, FALSE, &pDeviceObject);

	if (my_status == STATUS_SUCCESS)
	{
		/* MajorFunction: is a list of function pointers for entry points into the driver. */
		for (uiIndex = 0; uiIndex < IRP_MJ_MAXIMUM_FUNCTION; uiIndex++)
			pDriverObject->MajorFunction[uiIndex] = my_UnSupportedFunction;

		//set IOCTL control function
		pDriverObject->MajorFunction[IRP_MJ_DEVICE_CONTROL] = my_IOCTLControl;

		/* DriverUnload is required to be able to dynamically unload the driver. */
		pDriverObject->DriverUnload = my_Unload;
		pDeviceObject->Flags |= 0;
		pDeviceObject->Flags &= (~DO_DEVICE_INITIALIZING);

		/* Create a Symbolic Link to the device. MyDriver -> \Device\MyDriver */
		IoCreateSymbolicLink(&usDosDeviceName, &usDriverName);

	}

	return my_status;
}
