from ctypes import *
from ctypes.wintypes import *
import struct, sys, os, time
import optparse

kernel32 = windll.kernel32
ntdll = windll.ntdll

#GLOBAL VARIABLES

if __name__ == '__main__':
	usage = "Usage: %prog [options]"
	parser = optparse.OptionParser(usage=usage)
	parser.add_option('-d', '--drop', action='store_true', dest='drop', default=False, help='Drop file')
	options, args = parser.parse_args()
	
	#get driver handle
	GENERIC_READ  = 0x80000000
	GENERIC_WRITE = 0x40000000
	OPEN_EXISTING = 0x3
	DEVICE_NAME   = "\\\\.\\workshop"
	dwReturn	  = c_ulong()
	driver_handle = kernel32.CreateFileA(DEVICE_NAME, GENERIC_READ | GENERIC_WRITE, 0, None, OPEN_EXISTING, 0, None)

	#calculate IOCTL values
	FILE_DEVICE_UNKNOWN = 0x00000022
	METHOD_IN_DIRECT = 0x1
	FILE_READ_DATA = 0x1
	FILE_WRITE_DATA = 0x2
	CTL_CODE = lambda devtype, func, meth, acc: (devtype << 16) | (acc << 14) | (func << 2) | meth
	
	IOCTL_DROP_FILE = CTL_CODE(FILE_DEVICE_UNKNOWN, 0x800, METHOD_IN_DIRECT, FILE_READ_DATA | FILE_WRITE_DATA)

	IoStatusBlock = c_ulong()
	if(options.drop):
		ntdll.ZwDeviceIoControlFile(driver_handle, None, None, None, byref(IoStatusBlock), IOCTL_DROP_FILE, None, 0, None, 0)
	


